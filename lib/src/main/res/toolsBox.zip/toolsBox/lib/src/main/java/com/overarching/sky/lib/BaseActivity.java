package com.overarching.sky.lib;

import android.support.v7.app.AppCompatActivity;

/**
 * @author: KYE keke
 * @email: keke@ky-tech.com.cn
 * @date: 2023/2/18 16:12
 * 基类
 */
public class BaseActivity extends AppCompatActivity {
}
