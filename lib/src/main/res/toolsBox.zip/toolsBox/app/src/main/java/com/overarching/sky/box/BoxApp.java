package com.overarching.sky.box;

import android.app.Application;

/**
 * @author: KYE keke
 * @email: keke@ky-tech.com.cn
 * @date: 2023/2/18 14:51
 */
public class BoxApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
